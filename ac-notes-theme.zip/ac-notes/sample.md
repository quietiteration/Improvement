# Dijkstra · 堆优化最短路

> **方法卡**　图论 / 单源最短路 / 非负权
>
> 把「当前距离最小」的点确定下来，再用它更新相邻的点。

[TOC]

## 01 · 题目与约束

给定一张有向图，包含 $n$ 个点、$m$ 条边，求源点 $s$ 到每个点的最短距离。点的编号为 $1\ldots n$，允许重边与自环；所有边权均为非负整数。

| 项目 | 本笔记约定 |
| :--- | :--- |
| 数据范围 | $1\le n\le 2\times 10^5$，$0\le m\le 4\times 10^5$ |
| 边权范围 | $0\le w\le 10^9$ |
| 输入格式 | 第一行 `n m s`，随后 $m$ 行 `u v w` |
| 输出格式 | 按点编号输出最短距离；不可达输出 `-1` |
| 核心结构 | 邻接表 + 小根堆 |

**先判断能不能用：** 只要存在负权边，就不能直接使用这里的 Dijkstra 算法。零权边可以正常处理。

## 02 · 核心思路

### 距离估计与松弛

用 `dist[v]` 表示当前已经找到的、从 $s$ 到 $v$ 的最短路径长度。初始化源点距离为 $0$，其他点为 $+\infty$。

$$
\operatorname{dist}[s]=0,\qquad
\operatorname{dist}[v]=+\infty\quad(v\ne s)
$$

当从堆中取出点 $u$，尝试经过边 $(u,v,w)$ 改进 $v$ 的距离：

$$
\operatorname{dist}[v]\gets
\min\bigl(\operatorname{dist}[v],\operatorname{dist}[u]+w\bigr)
$$

只有距离**严格变小**时，才把新的 `(dist[v], v)` 放入堆中。

### 为什么要丢弃旧状态

同一个点的距离可能更新多次。标准库的 `priority_queue` 不直接修改堆内已有元素，因此旧的距离记录会继续留在堆里。

```cpp
auto [d, u] = pq.top();
pq.pop();
if (d != dist[u]) continue;
```

> **实现要点**
>
> 堆中的 `d` 是入堆时的距离快照，`dist[u]` 是最新值。两者不相等，说明这条堆记录已经过期，跳过即可。

### 正确性速记

每次取出的有效状态，对应尚未确定的点中距离估计最小的点 $u$。假设存在一条更短的 $s\to u$ 路径，考虑这条路径上第一个尚未确定的点 $x$：它的前驱已经被处理，所以经过前驱的松弛后，$x$ 的估计距离不会大于该路径到 $x$ 的长度。

由于后续边权非负，这个长度不大于整条路径到 $u$ 的长度，进而小于当前的 `dist[u]`；这与 $u$ 是最小距离估计的有效状态矛盾。因此，取出 $u$ 时，其最短距离已经确定。

## 03 · C++17 模板

```cpp
#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using State = pair<ll, int>;

struct Edge {
    int to;
    ll weight;
};

constexpr ll INF = numeric_limits<ll>::max() / 4;

vector<ll> dijkstra(int source, const vector<vector<Edge>>& graph) {
    vector<ll> dist(graph.size(), INF);
    priority_queue<State, vector<State>, greater<State>> pq;

    dist[source] = 0;
    pq.push({0, source});

    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (d != dist[u]) continue;  // 丢弃旧状态

        for (const auto& edge : graph[u]) {
            int v = edge.to;
            ll w = edge.weight;
            if (w > INF - d) continue;  // 保证 d + w 不超过 INF

            ll next_dist = d + w;
            if (next_dist < dist[v]) {
                dist[v] = next_dist;
                pq.push({next_dist, v});
            }
        }
    }
    return dist;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m, s;
    if (!(cin >> n >> m >> s)) return 0;
    vector<vector<Edge>> graph(n + 1);

    for (int i = 0; i < m; ++i) {
        int u, v;
        ll w;
        cin >> u >> v >> w;
        graph[u].push_back({v, w});
    }

    const auto dist = dijkstra(s, graph);
    for (int v = 1; v <= n; ++v) {
        if (v > 1) cout << ' ';
        cout << (dist[v] == INF ? -1 : dist[v]);
    }
    cout << '\n';
}
```

`INF` 必须大于所有可能的有限答案。本题非负权图的最短路总能选成简单路径，因此有限答案不超过 $(n-1)\times 10^9$，远小于这里的 `INF`。加法前的检查用于防止超出哨兵范围；修改数据范围时，必须重新确认这个前提。

## 04 · 手推样例

### 输入

```text
6 7 1
1 2 2
1 3 5
2 3 1
2 4 4
3 4 1
4 5 3
1 5 10
```

### 输出

```text
0 2 3 4 7 -1
```

从 $1$ 到 $5$ 的最短路径为 $1\to2\to3\to4\to5$，距离为 $2+1+1+3=7$。点 $6$ 不可达。

| 有效出堆点 | 距离 | 本轮改进 |
| :---: | ---: | :--- |
| 1 | 0 | `d[2]=2`，`d[3]=5`，`d[5]=10` |
| 2 | 2 | `d[3]=3`，`d[4]=6` |
| 3 | 3 | `d[4]=4` |
| 4 | 4 | `d[5]=7` |
| 5 | 7 | 无 |

堆中 `(5,3)`、`(6,4)` 和 `(10,5)` 都是旧状态，会被跳过。

## 05 · 复杂度与边界

| 部分 | 时间 | 额外空间 |
| :--- | :--- | :--- |
| 建图 | $O(n+m)$ | $O(n+m)$ |
| 距离数组初始化 | $O(n)$ | $O(n)$ |
| 扫描可达点的出边 | $O(m)$ | $O(1)$ |
| 堆的全部操作 | $O((m+1)\log(m+2))$ | $O(m+1)$ |

本实现采用「重复入堆、延迟删除旧状态」，成功松弛至多 $m$ 次。一般有向多重图的总时间可以统一写成 $O((n+m)\log(n+m+1))$，总空间为 $O(n+m)$；若图为简单图，常见写法为 $O((n+m)\log n)$（$n\ge2$）。[^heap]

## 06 · 易错点与复盘

- **堆方向写反：** `priority_queue` 默认是大根堆，需要 `greater<State>`。
- **距离用 `int`：** 单条边不溢出，不代表多条边累加也安全。
- **误写无向图：** 本题是有向图，只插入 `u → v`；无向图才需要反向边。
- **遗漏旧状态判断：** 会重复扫描出边，破坏上述复杂度保证。
- **把 `<` 改成 `<=`：** 零权环可能反复产生相同距离的状态。

- [x] 样例包含不可达点和被更新多次的点。
- [x] 已确认允许零权边，且所有边权非负。
- [ ] 独立默写模板，并测试单点图、重边、自环与零权环。
- [ ] 扩展记录 `parent[v]`，输出一条最短路径。

[^heap]: 堆中可能同时保留同一顶点的多条记录，因此这里把堆空间计为 $O(m+1)$，而不是直接记为 $O(n)$。
