AC Notes · 算法手记
Typora 算法竞赛笔记主题 / 1.0.0

一、开始使用

1. 解压 ac-notes-theme.zip。
2. 打开 Typora 的「偏好设置（或设置）→ 外观 → 打开主题文件夹」。
3. 将 ac-notes.css 和 ac-notes-night.css 直接复制到打开的主题文件夹。
   文件不能仍在压缩包里，也不要把它们藏在多一级的 ac-notes 子文件夹中。
4. 完全退出并重新打开 Typora。
5. 在「主题」菜单中选择 Ac Notes（浅色）或 Ac Notes Night（夜间）。
6. 用 Typora 打开 sample.md，检查中文、代码、目录、公式和表格效果。

只复制一个 CSS 文件也可以使用对应主题。两个主题都完整独立，
不依赖另一份 CSS，不下载远程字体，不要求安装插件。

官方安装说明：
https://support.typora.io/About-Themes/

二、文件说明

ac-notes.css           米白正文、青绿色标题、深蓝灰代码块
ac-notes-night.css     深蓝灰正文、薄荷绿标题、低亮度代码块
sample.md             Dijkstra 完整示例笔记，包含可编译 C++17 代码
solution-template.md  可复制使用的通用题解模板
preview.html          离线网页样式预览，可切换两种主题
README.txt            安装、设置、自定义与兼容说明

preview.html 要和两份 CSS 放在同一文件夹。它是静态排版预览，
代码高亮与公式为演示内容，不模拟 Typora 编辑、MathJax 或语法解析。
最终实际效果请在 Typora 中打开 sample.md 查看。

三、适合算法笔记的设计

• 三级主要标题有明显层次，便于区分题目、思路、证明、实现与复盘。
• 行内代码使用浅底标签；完整程序使用深色代码块，注释也保持清晰。
• 引用块可写「核心结论」「状态定义」「易错点」等速查内容。
• 公式块有留白与独立底色，保留 MathJax 的数学字体。
• 复杂度表格、任务清单、目录、脚注、YAML 信息块有对应样式。
• Mermaid 与其他图表使用浅色画布，便于在两种配色和打印中阅读。
• 两个主题都含打印规则：白色页面、浅底代码、长代码允许分页。

四、建议的 Typora 设置

进入「偏好设置 → Markdown」：

• 数学：启用「内联公式」，使 $...$ 正常渲染。
• 代码块：启用行号；按自己的习惯选择自动换行。
• 代码块：默认语言可设为 C++；缩进建议 4 个空格。

这些属于 Typora 的功能选项，主题负责显示样式，不会自动开启。
修改相关 Markdown 选项后，按 Typora 提示重启。

官方说明：
https://support.typora.io/Math/
https://support.typora.io/Code-Fences/

五、自定义字号、宽度、字体

正文字号：优先使用 Typora 的偏好设置。主题默认 16px。

在主题文件夹新建 ac-notes.user.css，为浅色版放入以下内容：

:root {
  --ac-page-width: 1040px;    /* 写代码需要更宽时增大 */
  --ac-code-size: 0.94rem;   /* 代码默认 0.875rem */
  --ac-leading: 1.85;        /* 正文行距 */
}

夜间版使用 ac-notes-night.user.css，同样填写即可。
宽度包含页面左右留白；窄窗口会自动缩小留白。
也可以直接编辑主题 CSS 顶部的同名参数。

字体按本机安装情况回退：中文使用系统黑体类字体；代码优先选择
JetBrains Mono、Cascadia Code、SFMono-Regular、Consolas 等等宽字体。
未安装这些字体也能使用，实际字形以系统回退结果为准。
如果 Linux 中文显示为方框，请安装本机可用的简体中文字体。

自定义样式加载顺序与文件命名：
https://support.typora.io/Add-Custom-CSS/

六、写作习惯

• 新题解：复制 solution-template.md，按实际需要删掉空段落。
• 标题：使用 #、##、###，可配合 01、02 作为手动章节编号。
• 目录：单独一行写 [TOC]。
• 代码：围栏语言填 cpp，才能得到 C++ 语法高亮。
• 公式：行内用 $...$，独立公式用上下两行 $$ 包围。
• 结论卡：使用普通 Markdown 引用符号 >，不需要额外 HTML。

主题不会自动给标题编号，目录与正文会保留你实际写下的标题。
主题也不提供代码运行、判题、折叠或自动识别题解段落的功能。

七、检查范围与常见问题

本包依据 Typora 官方主题变量与选择器编写，检查了样式结构、
两种配色的关键文本对比度，以及 Dijkstra 示例代码的编译和边界用例。
当前制作环境未安装 Typora，也未完成浏览器渲染实测；因此编辑光标、
各版本菜单细节和实际 PDF 分页仍以你本机为准。

主题不出现：检查文件扩展名为 .css，不是 .css.txt；检查放置层级，
并完全退出 Typora 后再启动。

样式和预期不一致：已有的 base.user.css、同名 .user.css 或插件
可能覆盖主题，可检查这些自定义设置。不要直接删除自己的旧配置。

公式显示原样：检查是否开启内联公式；块公式必须使用独立的 $$ 行。

代码没有高亮：确认代码围栏语言为 cpp 或其他 Typora 支持的语言。

长代码打印：已设置允许换行与分页；纸张、页边距及打印机设置会影响
分页位置，正式打印前请查看 Typora 的导出或打印预览。

官方主题接口与代码块参考：
https://theme.typora.io/doc/Write-Custom-Theme/
https://support.typora.io/Code-Block-Styles/
https://support.typora.io/Diagram-Options/

本包为可编辑主题文件，可按自己的笔记习惯继续修改。
